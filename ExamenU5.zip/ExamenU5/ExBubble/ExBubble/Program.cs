﻿using System;

namespace ExBubble
{
    class Burbuja
    {
        int[] vector;
        int pos;
        int cant;
        public void Inicializar()//Metodo donde pido la longitud del vector y los valores
        {
        
            Console.WriteLine("Ingrese longitud del Vector: ");
            cant = int.Parse(Console.ReadLine());
            vector = new int[cant];


            for (int f = 0; f < vector.Length; f++)
            {

                Console.Write("Ingrese un Valor ");
                int Aux;
                Aux = int.Parse(Console.ReadLine());
                if (Aux > 2 || Aux < 0) //Utilice un if para cuando el usuario ingrese un elemento no valido 
                {
                    Console.WriteLine("\nIngrese unicamente valores de 0 A 2");// Despligue del mensaje erroneo
                    Console.Write("Ingrese un numero: ");
                    Aux = int.Parse(Console.ReadLine());
                }
                vector[f] = Aux;

            }
        }
        public void bubble()//Metodo del ordenamiento de burbuja
        {

            for (int a = 1; a < vector.Length; a++)
                for (int b = vector.Length - 1; b >= a; b--)//ordena los valores de menor a mayor
                {
                    if (vector[b - 1] > vector[b])
                    {
                        pos = vector[b - 1];
                        vector[b - 1] = vector[b];
                        vector[b] = pos;
                    }
                }
        }
        public void Display()//Despligue del vector de menor a mayor
        {
            Console.WriteLine("Vector ordenados en forma ascendente");
            for (int f = 0; f < vector.Length; f++)
            {
                Console.Write(vector[f] + "  ");
            }
            Console.ReadKey();
        }
        static void Main(string[] args)
        {

            Burbuja burbuja = new Burbuja();//Instanciamos todos los metodos
            burbuja.Inicializar();
            burbuja.bubble();
            burbuja.Display();
           

        }

      }

   }

    


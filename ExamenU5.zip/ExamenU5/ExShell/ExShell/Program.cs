﻿using System;

namespace ExShell
{
    class ExShell
    {
        private int[] Vektor;

        public void Inicializar()//Este metodo se utiliza para pedir la longitud del vector y los valores
        {

            Console.Write("Cuantos longitud del vector:");
            int cant;
            cant = int.Parse(Console.ReadLine());
            Vektor = new int[cant];
            for (int f = 0; f < Vektor.Length; f++)
            {
                Console.Write("Ingrese elemento " + (f + 1) + ": ");
                cant = int.Parse(Console.ReadLine());
                Vektor[f] = cant;
            }
        }

        public void Shell()//Metodo de ordemiento Shell
        {
            int salto = 0;
            int sw = 0;
            int vAux = 0;
            int e = 0;
            salto = Vektor.Length / 2;
            while (salto > 0)
            {
                sw = 1;
                while (sw != 0)
                {
                    sw = 0;
                    e = 1;
                    while (e <= (Vektor.Length - salto))
                    {
                        if (Vektor[e - 1] > Vektor[(e - 1) + salto])
                        {
                            vAux = Vektor[(e - 1) + salto];
                            Vektor[(e - 1) + salto] = Vektor[e - 1];
                            Vektor[(e - 1)] = vAux;
                            sw = 1;
                        }
                        e++;
                    }
                }
                salto = salto / 2;
            }
        }

        public void Display()//En este metodo desplegamos el vector ordenado
        {
            Console.WriteLine("Vector ordenados en forma ascendente");
            for (int f = 0; f < Vektor.Length; f++)
            {
                Console.Write(Vektor[f] + "  ");
            }
            Console.ReadKey();
        }


        static void Main(string[] args)
        {
            ExShell Sort = new ExShell();//Instanciamos nuestros metodos
            Sort.Inicializar();
            Sort.Shell();
            Sort.Display();
        }
    }
}

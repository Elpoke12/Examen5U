﻿using System;

namespace ExLetras
{
    class Program
    {
        static void Main(string[] args)
        {
            string frase;
            int num = 29;

            Console.WriteLine("El espacio que tiene para ingresar palabras es: " + num);//Aqui le definimos al usuario el espacio que tiene para escribir las palabras
            string[] Vektor = new string[num];
            Console.WriteLine("Frase a ordenar es:");
            Console.WriteLine("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce varius, augue vitae tincidunt viverra, sem felis bibendum nisl, id cursus diam leo sit amet urna. Duis ac massa est.");

            for (int f = 0; f < Vektor.Length; f++)
            {
                Console.WriteLine("Ingrese una palabra#" + (f + 1) + ":");//En esta parte le pedimos al usuario que ingrese sus palabras
                frase = Console.ReadLine();
                Vektor[f] = frase;
            }
            {
                string t = " ";
                for (int a = 1; a < Vektor.Length; a++)//metodo de ordemamiento por orden alfabetico
                {
                    for (int b = 0; b < Vektor.Length - a; b++)
                    {
                        if (Vektor[b].CompareTo(Vektor[b + 1]) > 0)
                        {
                            t = Vektor[b];
                            Vektor[b] = Vektor[b + 1];
                            Vektor[b + 1] = t;
                        }
                    }
                }
            }

            {
                for (int f = 0; f < Vektor.Length; f++)//Desplegamos todas nuestras palabras ordenadas
                {
                    Console.WriteLine("Frase ordenada: ");
                    Console.Write(Vektor[f] + "\n");
                }
            }


            Console.ReadKey();
        }
    }
}

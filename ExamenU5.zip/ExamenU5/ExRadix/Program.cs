﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExRadix
{
    class Program
    {
        static void Main(string[] args)
        {
           ExRadix Sort = new ExRadix(); //Declaracion de la clase, en este caso externa
            Random NumRan = new Random();

            int[] Vektor = new int[80];//Declaramos nuestro vector

            for (int i = 0; i < 80; i++)
            {
                Vektor[i] = NumRan.Next(0, 69) + i;//Aqui se encuentra nuestro rango de valores positivos
            }

            Console.WriteLine("Vector sin arreglar ");

            foreach (var item in Vektor)
            {
                Console.Write(" " + item);
            }
            Console.WriteLine("\n");

            Sort.Radix(Vektor);
            Console.WriteLine("\n");
            Console.WriteLine("Valores Ordenados: ");//Despligue de valores ordenados

            foreach (var item in Vektor)
            {
                Console.Write(" " + item);

            }

            Console.ReadKey();
        }
    }
}

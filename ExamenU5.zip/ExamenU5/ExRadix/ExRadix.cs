﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExRadix
{
    class ExRadix//Clase externa del metodo de ordenamiento Radix
    {
        int Valor, i; 
        public void Radix(int[] Metodo)
        {
            int[] Vector = new int[Metodo.Length];
            for (int aux = 31; aux > -1; --aux)
            {
                i = 0;
                for (Valor = 0; Valor < Metodo.Length; ++Valor)// inicia el acomodo de valores
                {
                    bool Move = (Metodo[Valor] << aux) >= 0;
                    if (aux == 0 ? !Move : Move)
                        Metodo[Valor - i] = Metodo[Valor];
                    else
                        Vector[i++] = Metodo[Valor];
                }

                Array.Copy(Vector, 0, Metodo, Metodo.Length - i, i);
            }
        }
    }
}
